import { useState } from "react";

const SHOPS = [
  { id: 1, name: "Lakshmi Medicals", cat: "Medicine", time: "20 min", img: "💊" },
  { id: 2, name: "More Supermarket", cat: "Grocery", time: "30 min", img: "🛒" },
  { id: 3, name: "Hyderabad Biryani Point", cat: "Food", time: "25 min", img: "🍛" },
  { id: 4, name: "Any Shop - Just Tell Us", cat: "Anything", time: "30 min", img: "📦" },
];

export default function App() {
  const [page, setPage] = useState("home");
  const [distance, setDistance] = useState(2.5);
  const [order, setOrder] = useState(null);
  const [pickup, setPickup] = useState("");
  const [drop, setDrop] = useState("");

  const calculateCharge = (d) => {
    if (d < 0.5 || d > 8) return null;
    return 30 + Math.round(d * 10);
  };

  const charge = calculateCharge(distance);
  const isOutOfRange = charge === null;

  const placeOrder = () => {
    if (!pickup.trim() || !drop.trim()) {
      alert("Please fill pickup and drop addresses.");
      return;
    }

    if (isOutOfRange) {
      alert("Sorry! Delivery is available only within 0-8 km.");
      return;
    }

    const newOrderDetails = {
      id: Date.now(),
      pickup: pickup.trim(),
      drop: drop.trim(),
      distance,
      charge,
      status: "Partner Assigned",
      otp: Math.floor(1000 + Math.random() * 9000).toString(),
    };

    setOrder(newOrderDetails);
    setPage("tracking");
  };

  const startNewOrder = () => {
    setPickup("");
    setDrop("");
    setDistance(2.5);
    setOrder(null);
    setPage("home");
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-black p-4 text-white">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">GunturGo 🚀</h1>
          <span className="rounded-full bg-green-500 px-2 py-1 text-xs">
            0-8km ONLY
          </span>
        </div>
        <p className="mt-1 text-xs text-gray-300">
          📍 Guntur, Auto-detecting...
        </p>
      </header>

      {/* Home Page */}
      {page === "home" && (
        <main className="p-4">
          <div className="flex items-center rounded-xl bg-white p-3 shadow">
            <span className="mr-2">🔍</span>
            <input
              className="w-full text-sm outline-none"
              placeholder="Order anything in Guntur..."
              aria-label="Search shops"
            />
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {["Food", "Grocery", "Medicine", "Parcel"].map((category) => (
              <button
                type="button"
                key={category}
                onClick={() => setPage("order")}
                className="cursor-pointer rounded-xl bg-white p-3 text-center shadow"
              >
                <div className="text-2xl">
                  {category === "Food"
                    ? "🍔"
                    : category === "Grocery"
                    ? "🥦"
                    : category === "Medicine"
                    ? "💊"
                    : "📦"}
                </div>
                <div className="mt-1 text-xs font-semibold">{category}</div>
              </button>
            ))}
          </div>

          <h3 className="mb-3 mt-6 font-bold">
            Nearby Stores (within 8km)
          </h3>

          {SHOPS.map((shop) => (
            <button
              type="button"
              key={shop.id}
              onClick={() => setPage("order")}
              className="mb-3 flex w-full cursor-pointer justify-between rounded-xl bg-white p-4 text-left shadow"
            >
              <div className="flex gap-3">
                <div className="text-3xl">{shop.img}</div>
                <div>
                  <div className="text-sm font-bold">{shop.name}</div>
                  <div className="text-xs text-gray-500">
                    {shop.cat} • {shop.time}
                  </div>
                </div>
              </div>
              <div className="mt-2 text-xs font-bold text-green-600">
                30% OFF
              </div>
            </button>
          ))}
        </main>
      )}

      {/* Order Page */}
      {page === "order" && (
        <main className="p-4">
          <button
            type="button"
            onClick={() => setPage("home")}
            className="mb-4 text-sm"
          >
            ← Back
          </button>

          <h2 className="text-lg font-bold">Create Order</h2>

          <div className="mt-4 space-y-4 rounded-xl bg-white p-4 shadow">
            <input
              type="text"
              value={pickup}
              onChange={(event) => setPickup(event.target.value)}
              placeholder="Pickup - Shop Name / Address"
              className="w-full rounded-lg border p-3 text-sm"
            />

            <input
              type="text"
              value={drop}
              onChange={(event) => setDrop(event.target.value)}
              placeholder="Drop - Your Address"
              className="w-full rounded-lg border p-3 text-sm"
            />

            {/* Distance Slider */}
            <div>
              <label className="text-xs font-bold">Distance (km)</label>
              <input
                type="range"
                min="0.5"
                max="12"
                step="0.5"
                value={distance}
                onChange={(event) => setDistance(Number(event.target.value))}
                className="w-full"
              />

              <div className="mt-1 flex justify-between text-xs">
                <span>{distance} km</span>
                {isOutOfRange ? (
                  <span className="font-bold text-red-600">OUT OF RANGE</span>
                ) : (
                  <span className="font-bold text-green-600">In Range</span>
                )}
              </div>
            </div>

            {/* Delivery Charge */}
            <div className="rounded-lg bg-gray-100 p-3">
              <div className="flex justify-between text-sm">
                <span>Base Charge</span>
                <span>₹30</span>
              </div>

              <div className="flex justify-between text-sm">
                <span>Distance Charge ({distance} km × ₹10)</span>
                <span>₹{Math.round(distance * 10)}</span>
              </div>

              <div className="mt-2 flex justify-between border-t pt-2 font-bold">
                <span>Total</span>
                <span>
                  {charge !== null ? `₹${charge}` : "Not Deliverable"}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={placeOrder}
              disabled={isOutOfRange}
              className={`w-full rounded-lg p-3 font-bold text-white ${
                isOutOfRange
                  ? "cursor-not-allowed bg-gray-400"
                  : "bg-black hover:bg-gray-800"
              }`}
            >
              {isOutOfRange
                ? "Beyond 8km - Can't Deliver"
                : `Pay ₹${charge} & Place Order`}
            </button>
          </div>
        </main>
      )}

      {/* Tracking Page */}
      {page === "tracking" && order && (
        <main className="p-4">
          <h2 className="text-lg font-bold">Order Tracking</h2>

          <div className="mt-4 rounded-xl bg-white p-4 shadow">
            <div className="text-sm">
              Order ID: <b>{order.id}</b>
            </div>

            <div className="mt-2 text-sm">
              Pickup: <b>{order.pickup}</b>
            </div>

            <div className="mt-2 text-sm">
              Drop: <b>{order.drop}</b>
            </div>

            <div className="mt-2 text-sm">
              Delivery Charge: <b>₹{order.charge}</b>
            </div>

            <div className="mt-4 text-sm">
              OTP for Delivery:
              <span className="ml-2 text-xl font-bold">{order.otp}</span>
            </div>

            <div className="mt-4 space-y-3">
              {[
                "Order Placed ✓",
                "Partner Assigned ✓ - Ravi",
                "Picked Up - On the way",
                "Delivered",
              ].map((status, index) => (
                <div
                  key={index}
                  className={`flex gap-2 text-sm ${
                    index < 2
                      ? "font-bold text-green-600"
                      : "text-gray-400"
                  }`}
                >
                  <div>●</div>
                  <div>{status}</div>
                </div>
              ))}
            </div>

            <div className="mt-6 rounded-lg bg-black p-3 text-center text-sm text-white">
              Delivery Boy Live: 1.2km away • On Bike
            </div>

            <button
              type="button"
              onClick={startNewOrder}
              className="mt-4 w-full rounded-lg border p-3"
            >
              New Order
            </button>
          </div>
        </main>
      )}
    </div>
  );
}
