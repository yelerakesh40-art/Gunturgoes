# GunturGo React App

## Requirements
- Node.js (18 or newer recommended)
- npm

## Run the project

1. Extract the ZIP file.
2. Open the extracted `gunturgo-react` folder in VS Code.
3. Open the VS Code terminal in that folder.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL printed in the terminal (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
```

The app uses React, Vite, and Tailwind CSS.
